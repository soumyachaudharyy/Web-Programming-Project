show databases;
drop database bhagwanbachao;
create database bhagwanbachao;
use bhagwanbachao;
show tables;

CREATE TABLE `Classes` (
  class_id VARCHAR(5) NOT NULL PRIMARY KEY
);

CREATE TABLE `Student_Details` (
  student_id varchar(6) NOT NULL PRIMARY KEY,
  full_name VARCHAR(50) DEFAULT NULL,
  class_id VARCHAR(5) NOT NULL, 
  section VARCHAR(3) DEFAULT NULL,
  gender ENUM('Male', 'Female', 'Other') DEFAULT NULL,
  FOREIGN KEY (class_id) REFERENCES `Classes` (class_id)
);

CREATE TABLE `Family_Details` (
  student_id varchar(6) NOT NULL PRIMARY KEY,
  AADHAR_NUMBER VARCHAR(50),
  -- Full_Name CHAR(50) NULL,
  Father_Name VARCHAR(50) DEFAULT NULL,
  Mother_Name VARCHAR(50) DEFAULT NULL,
  Social_Category VARCHAR(50) DEFAULT NULL,
  FATHER_PHONE BIGINT DEFAULT NULL,
  FATHER_AADHAR VARCHAR(50) DEFAULT NULL,
  MOTHER_AADHAR VARCHAR(50) DEFAULT NULL,
  FOREIGN KEY (student_id) REFERENCES `Student_Details` (student_id)
);

CREATE TABLE `Additional_Details` (
  student_id varchar(6) NOT NULL PRIMARY KEY,
  SRN_NUMBER BIGINT NULL,
  Pen_num BIGINT,
  Admission_no INT NULL,
  DOB DATE NULL,
  admission_date DATE NULL,
  FOREIGN KEY (student_id) REFERENCES `Student_Details` (student_id)
);

CREATE TABLE `Subjects` (
  subject_id VARCHAR(4) NOT NULL PRIMARY KEY,
  subject_name VARCHAR(50) NOT NULL
);

CREATE TABLE `Student_Grades` (
  grade_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id varchar(6) NOT NULL,
  subject_id VARCHAR(4) NOT NULL,
  -- Term 1 columns
  `period_test_1` INT,
  `notebook_1` INT,
  `sub_en_1` INT,
  `term_1` INT,
  `total_1` INT,
  -- Term 2 columns
  `period_test_2` INT,
  `notebook_2` INT,
  `sub_en_2` INT,
  `term_2` INT,
  `total_2` INT,
  -- Overall total and percentage
  `gtotal` INT,
  `percentage` DECIMAL(5, 2),
  FOREIGN KEY (student_id) REFERENCES `Student_Details` (student_id),
  FOREIGN KEY (subject_id) REFERENCES `Subjects` (subject_id)
);

CREATE TABLE `Teacher_Details` (
  teacher_id varchar(6) NOT NULL PRIMARY KEY,
  full_name VARCHAR(50) NOT NULL,
  phone BIGINT DEFAULT NULL,
  age INT DEFAULT NULL,
  gender ENUM('Male', 'Female', 'Other') DEFAULT NULL
);

select * from teacher_details;
desc teacher_details;
drop table teacher_subjects;
drop table teacher_details;

CREATE TABLE `Teacher_Subjects` (
  teacher_id VARCHAR(6) NOT NULL,
  subject_id VARCHAR(4) NOT NULL,
  PRIMARY KEY (teacher_id, subject_id),
  FOREIGN KEY (teacher_id) REFERENCES `Teacher_Details` (teacher_id),
  FOREIGN KEY (subject_id) REFERENCES `Subjects` (subject_id)
);

CREATE TABLE `Class_Subjects` (
  class_id VARCHAR(5) NOT NULL,
  subject_id VARCHAR(4) NOT NULL,
  PRIMARY KEY (class_id, subject_id),
  FOREIGN KEY (class_id) REFERENCES `Classes` (class_id),
  FOREIGN KEY (subject_id) REFERENCES `Subjects` (subject_id)
);

select * from teacher_subjects;
